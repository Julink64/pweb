<?php

namespace Pweb\MainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PwebMainBundle extends Bundle
{
}
