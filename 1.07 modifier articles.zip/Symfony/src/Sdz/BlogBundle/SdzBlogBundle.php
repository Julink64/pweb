<?php

namespace Sdz\BlogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SdzBlogBundle extends Bundle
{
}
